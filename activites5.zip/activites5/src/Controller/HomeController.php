<?php

namespace App\Controller;

//use App\Repository\UserRepository;
//use App\Repository\UserRepository;
use App\Entity\User;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
//composer require doctrine/annotations

class HomeController extends AbstractController
{
    /**
     * @Route("/users", name="home")
     * @return Response
     */

    public function SetUser()
    {
        $user = new User();
        $user->setFirstname('ahmed');
        $user->setLastname('damak');
        $user->setEmail('ahmed@talan.com');
        $user->setAddress('sfax');
        //$user->setBirthdateAt('2006-02-02');

        $entityManager = $this->getDoctrine()->getManager();

        $entityManager->persist($user);

        /* on exécute maintenant les 2 requêtes qui vont ajouter

                les objets $event et $event2 en base de données */

        $entityManager->flush();


        return new Response($this->render('index.html.twig'));
    }
}
