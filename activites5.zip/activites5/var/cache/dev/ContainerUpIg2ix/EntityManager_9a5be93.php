<?php

namespace ContainerUpIg2ix;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderba312 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer6ba2c = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesa568e = [
        
    ];

    public function getConnection()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getConnection', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getMetadataFactory', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getExpressionBuilder', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'beginTransaction', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getCache', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getCache();
    }

    public function transactional($func)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'transactional', array('func' => $func), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'wrapInTransaction', array('func' => $func), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'commit', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->commit();
    }

    public function rollback()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'rollback', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getClassMetadata', array('className' => $className), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'createQuery', array('dql' => $dql), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'createNamedQuery', array('name' => $name), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'createQueryBuilder', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'flush', array('entity' => $entity), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'clear', array('entityName' => $entityName), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->clear($entityName);
    }

    public function close()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'close', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->close();
    }

    public function persist($entity)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'persist', array('entity' => $entity), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'remove', array('entity' => $entity), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'refresh', array('entity' => $entity), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'detach', array('entity' => $entity), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'merge', array('entity' => $entity), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getRepository', array('entityName' => $entityName), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'contains', array('entity' => $entity), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getEventManager', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getConfiguration', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'isOpen', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getUnitOfWork', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getProxyFactory', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'initializeObject', array('obj' => $obj), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'getFilters', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'isFiltersStateClean', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'hasFilters', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return $this->valueHolderba312->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer6ba2c = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderba312) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderba312 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderba312->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, '__get', ['name' => $name], $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        if (isset(self::$publicPropertiesa568e[$name])) {
            return $this->valueHolderba312->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderba312;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderba312;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderba312;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderba312;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, '__isset', array('name' => $name), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderba312;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderba312;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, '__unset', array('name' => $name), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderba312;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderba312;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, '__clone', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        $this->valueHolderba312 = clone $this->valueHolderba312;
    }

    public function __sleep()
    {
        $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, '__sleep', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;

        return array('valueHolderba312');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer6ba2c = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer6ba2c;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer6ba2c && ($this->initializer6ba2c->__invoke($valueHolderba312, $this, 'initializeProxy', array(), $this->initializer6ba2c) || 1) && $this->valueHolderba312 = $valueHolderba312;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderba312;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderba312;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
